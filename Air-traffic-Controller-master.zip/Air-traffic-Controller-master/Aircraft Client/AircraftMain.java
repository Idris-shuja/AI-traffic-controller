
public class AircraftMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Login l=new Login("LOGIN");
		l.setSize(500,400);
		l.setLocation(200,50);
		l.setVisible(true);
		
		
	}

}
